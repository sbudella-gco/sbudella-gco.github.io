#! /bin/sh

print '('
if [ "X$1" = "X-t" ]; then
	sed -e '/^? *$/ d' -e 's/^? \(..*\)$/(\1)/'
else
	sed 's/\(^[+-]\) \(..*\)$/((\2) . \1)/' | tr '+-' '10'
fi
print ')'
