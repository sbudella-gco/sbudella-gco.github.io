import logging
import sys


log = logging.getLogger('dfa')

StateUndefined = -1


class DFA(object):
    def __init__(self, fas, ttable, frs=(), unlabelled=str()):
        """
        parameters:
        fas is a sequence of integers denoting the accepting states;
        frs is a sequence of integers denoting the rejecting states;
        ttable is a map of (state, symbol) to state;
        unlabelled is the symbol for the dummy starting state.
        """
        self.state = None
        self.fas = fas
        self.frs = frs
        self.unlabelled = unlabelled
        self.ttable = ttable
        self.alphabet = frozenset([sym for _, sym in self.ttable.iterkeys()])
        self.dfa = self.__build()
        self.dfa.send(None)

    def __build(self):
        while True:
            symbol = (yield self.state)
            self.state = self.ttable.get((self.state, symbol), StateUndefined)

    def walk(self, string):
        self.state = self.unlabelled 
        for symbol in string:
            log.debug('symbol: %r', symbol)
            current_state = self.dfa.send(symbol)
            log.debug('current state: %r', self.state)
            if current_state == StateUndefined:
                return current_state
        return current_state

    def accept(self, string):
        self.state = 1
        state = self.walk(string)
        if state in self.fas:
            return True
        return False


if __name__ == "__main__":
    # describe an automaton whose language is
    # all the even binary strings
    ttable = {
        (1, '0'): 1,
        (1, '1'): 5,
        (5, '0'): 1,
        (5, '1'): 5,
    }
    dfa = DFA((1,), ttable, (5,), unlabelled=1)
    print dfa.accept('00111001')
    print dfa.accept('00111100')
    print dfa.accept('000101010101010100000001000')
