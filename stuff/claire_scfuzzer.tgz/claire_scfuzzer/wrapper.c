/*
 * sigcontext fuzzer wrapper;
 * author: Giuseppe Cocomazzi;
 * contact: sbudella at gmail.com;
 * date: 29 may 2008;
 */
 

#include <sys/reg.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <linux/user.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <signal.h>

#define FUZZER_PATH		"./claire" 
#define FUZZER_NAME		"claire"
#define FUZZER_LOGFILE		"claire.log"
#define BEAST_MARK		0x666

int main(int argc,char *argv[])
{
	pid_t child; 
	unsigned int seed = 0; 
	unsigned long long t = 0;
	char current_time[60];
	time_t now = 0;
	struct user_regs_struct regs;
	unsigned long seed_addr = 0x0;
	int status;

	memset(current_time,0,60);

	FILE *log = fopen(FUZZER_LOGFILE,"a");
	if(!log) {
		perror("fopen");
		exit(EXIT_FAILURE);
	}

	if(argc != 2)
		t = ULLONG_MAX;
	else
		t = atoll(argv[1]); 

	now = time(NULL);
	strftime(current_time,60,"%a %h %d %H:%M:%S",localtime(&now));
	fprintf(log,"****** claire fuzzing session started on: %s\n",
		current_time);

while(t--) {
	child = fork();
	if(!child) {
		ptrace(PTRACE_TRACEME,0,NULL,NULL);
		if(execl(FUZZER_PATH,FUZZER_NAME,NULL) < 0) {
			perror("execl");
			exit(EXIT_FAILURE);
		}

	} else {
		
		while(1) {
			wait(&status);
			if(WIFEXITED(status)) {
				fprintf(log,"claire exited with code: %d\n",
					WEXITSTATUS(status));
				break;
			}

			else if(WIFSIGNALED(status)) {
				fprintf(log,"claire terminated by signal: %d\n",
					WTERMSIG(status));
				fprintf(log,"regs:\n");
				fprintf(log,
				"eax =\t\t0x%lx;\n"
				"ecx =\t\t0x%lx;\n"
				"edx =\t\t0x%lx;\n"
				"ebx =\t\t0x%lx;\n"
				"esp =\t\t0x%lx;\n"
				"ebp =\t\t0x%lx;\n"
				"esi =\t\t0x%lx;\n"
				"edi =\t\t0x%lx;\n"
				"eip =\t\t0x%lx;\n"
				"eflags =\t0x%lx;\n"
				"cs =\t\t0x%x;\n"
				"ss =\t\t0x%x;\n"
				"ds =\t\t0x%x;\n"
				"es =\t\t0x%x;\n"
				"fs =\t\t0x%x;\n"
				"gs =\t\t0x%x;\n",
				regs.eax,regs.ecx,
				regs.edx,regs.ebx,
				regs.esp,regs.ebp,
				regs.esi,regs.edi,
				regs.eip,regs.eflags,
				regs.cs,regs.ss,
				regs.ds,regs.es,
				regs.fs,regs.gs);

				break;
			}

			else if(WIFSTOPPED(status))
				switch(WSTOPSIG(status)) {
					case SIGILL:
					case SIGBUS:
					case SIGSEGV:
					case SIGSYS:
						fprintf(log,"claire faulted: \
							 %d\n",
							WTERMSIG(status));
						break;

					/* claire received SIGUSR1, so the
					   custom signal handler must be
					   notified: ptrace uses to stop the
					   tracing process when signals income; 
					   signals themselves are blocked and
					   delivered on demand to the process
					   with PTRACE_CONT and the data field
					   set to the signal number */
					case SIGUSR1:
						if(ptrace(PTRACE_CONT,child,
							NULL,SIGUSR1) < 0) {
							perror("ptrace_cont");
							exit(EXIT_FAILURE);
						}
						continue;
				}
	
			if(ptrace(PTRACE_GETREGS,child,NULL,&regs) < 0) {
				perror("ptrace_getregs");
				exit(EXIT_FAILURE);
			}

			/* check whether eax is BEAST_MARK; if so, edx is set
			   to the address of SEED, that is the location where
			   we can get the seed returned by time(NULL) */ 
			if(regs.eax == BEAST_MARK)
				seed_addr = regs.edx;

			if(regs.eip == seed_addr) {
				/* get the seed as returned by time(NULL) */ 
				seed = regs.eax;
				fprintf(log,"seed:\t\t%d\n",seed);
				
				/* send claire a SIGUSR1 to activate the
				   fuzzer signal handler */
				kill(child,SIGUSR1);
			}

			if(ptrace(PTRACE_SINGLESTEP,child,NULL,NULL) < 0) {
				perror("ptrace_singlestep");
				exit(EXIT_FAILURE);
			}
		} 
	}
} /* while(t--) main cycle */

	now = time(NULL);
	strftime(current_time,60,"%a %h %d %H:%M:%S",localtime(&now));
	fprintf(log,"****** claire fuzzing session ended at: %s\n",
		current_time);
	fclose(log);
	return 0;
		

}

