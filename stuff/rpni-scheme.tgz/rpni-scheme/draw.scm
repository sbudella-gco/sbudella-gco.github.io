#! /usr/local/bin/csi -script

(use posix)

(use utilities)
(use backbone)
(use pta)
(use rpni)

(define (dot-fas-nodes Fas)
 (cons "node [shape = doublecircle];"
  (map
   (lambda (a)
    (with-output-to-string (lambda () (printf "~s;" a))))
   Fas)))


(define (dot-nodes table)
 (cons "node [shape = circle];"
  (map
   (lambda (elem)
    (let* ((key (extract-key elem))
           (state (car key))
           (symbol (cdr key))
           (next (extract-state elem)))
     (with-output-to-string (lambda () (printf "~s -> ~s [label = \"~s\"];" state next symbol)))))
   table)))

(let*-values (((pos-sample neg-sample) (read-samples))
              ((table Fas) (rpni pos-sample neg-sample)))

 (print "digraph finite_state_machine {")
 (print "\trankdir=LR;")
 (for-each
  (lambda (s) (print "\t" s))
  (append (dot-fas-nodes Fas) (dot-nodes table)))
 (print "}")

 (let ((dump-port (open-output-file* (duplicate-fileno 4))))
  (fprintf dump-port "~s" (list
   (alphabet pos-sample)
   table
   Fas))))
