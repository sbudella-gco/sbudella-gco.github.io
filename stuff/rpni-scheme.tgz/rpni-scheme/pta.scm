(module pta
 (alphabet build-table&fas build-pta) 

 (import chicken scheme)
 (use srfi-1)
 (use backbone)
 (use dfa)


 (define (counter start)
  (lambda ()
    (begin
     (set! start (+ start 1))
      start)))


 (define (alphabet xss)
  (fold-right
   (lambda (xs acc)
    (let loop ((xs xs) (acc acc))
     (if (eq? xs '()) acc
      (let ((x (car xs)))
       (if (in x acc) (loop (cdr xs) acc)
        (loop (cdr xs) (cons x acc)))))))
   '()
   xss))


 (define (make-branch xs table)
  (let ((next (counter (last-state table))))
  (let helper ((xs xs) (state 0) (result '()))
   (if (eq? xs '()) result
    (let* ((key (make-key state (car xs))) (elem (look-table key table)))
     (let ((next-state (next)))
      (if elem (helper (cdr xs) (extract-state elem) result)
       (helper (cdr xs) next-state (cons (make-elem key next-state) result)))))))))


 ;;; return a couple whose first element is the pta-table
 ;;; and the second element is the list of the accepting states.
 ;;; The latter ones are extracted from the car of each branch
 ;;; since make-branch returns transition element in reversed order,
 ;;; so the first is actually the last element of the branch, which
 ;;; for a pta is always an accepting state for the given sequence.
 ;;;
 (define (build-table&fas xss)
  (let helper ((xss xss) (table (init-table)) (Fas '()))
   (if (eq? xss '()) (values table Fas)
    (let ((xs (car xss)))
     (let ((branch (make-branch xs table)))
      (helper (cdr xss) (append branch table)
              (if (eq? branch '()) Fas (cons (extract-state (car branch)) Fas))))))))


 (define (build-pta xss)
  (call-with-values
   (lambda () (build-table&fas xss))
   (lambda (table Fas) (DFA (alphabet xss) (table->trans-func table) 0 Fas '()))))
   
) ; end module
