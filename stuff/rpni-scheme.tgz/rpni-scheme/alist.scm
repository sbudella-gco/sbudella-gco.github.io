(module alist 
 (init-table last-state look-table extract-key extract-state make-elem make-key in)
 (import chicken scheme)
 (use srfi-1)

 (define-syntax look-table
  (syntax-rules ()
   ((look-table key table) (assoc key table))))

 (define-syntax extract-key
  (syntax-rules ()
   ((extract-key elem) (car elem))))

 (define-syntax extract-state
  (syntax-rules ()
   ((extract-state elem) (cdr elem))))

 (define-syntax make-elem
  (syntax-rules ()
   ((make-elem key next-state) (cons key next-state))))

 (define-syntax make-key
  (syntax-rules ()
   ((make-key state symbol) (cons state symbol))))

 (define-syntax in
  (syntax-rules ()
   ((in x seq) (if (member x seq) #t #f))))

 (define (init-table . table)
  (let ((table (optional table '())))
   table))

 (define (last-state table)
  (fold-right
   (lambda (x y)
    (let ((n (extract-state x)))
     (if (>= n y) n y)))
   0
   table)) )


