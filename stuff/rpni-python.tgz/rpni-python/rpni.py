from dfa import DFA
from pta import PTA, Sample
from collections import namedtuple
from copy import copy


def compatible(dfa, sample):
    for s in sample.negative:
        if dfa.accept(s):
            return False
    return True


class RPNI(object):
    def __init__(self, sample):
        self.sample = sample if isinstance(sample, Sample) else Sample(sample)
        self.dfa = PTA(self.sample.positive, unlabelled=1)
        red = self.dfa.unlabelled
        self.reds = set([red])
        self.blues = set([self.dfa.ttable[(red, sym)] for sym in
                         self.dfa.alphabet if (red, sym) in self.dfa.ttable])

    def __copy__(self):
        p = namedtuple('proxydfa', ['ttable', 'fas', 'frs', 'unlabelled'])
        p.ttable = copy(self.dfa.ttable)
        p.fas = copy(self.dfa.fas)
        p.frs = copy(self.dfa.frs)
        p.unlabelled = self.dfa.unlabelled 
        return p

    def choose(self):
        return sorted(self.blues)[0]

    def promote(self, blue):
        self.reds.add(blue)
        for s in self.dfa.alphabet:
            next = self.dfa.ttable.get((blue, s))
            if next is not None:
                self.blues.add(next)

    def merge(self, red, blue):
        proxy = copy(self)
        for q, n in proxy.ttable.iteritems():
            if n == blue:
                proxy.ttable[q] = red
                break
        self.fold(proxy, red, blue)
        return proxy

    def fold(self, proxy, red, blue):
        if blue in proxy.fas:
            proxy.fas.add(red)
            proxy.fas.remove(blue)
        for s in self.dfa.alphabet:
            blue_next = proxy.ttable.get((blue, s))
            if blue_next is not None:
                red_next = proxy.ttable.get((red, s))
                if red_next is not None:
                    self.fold(proxy, red_next, blue_next)
                else:
                    proxy.ttable[(red, s)] = blue_next
                proxy.ttable.pop((blue, s))

    def update_frs(self):
        self.dfa.frs = set(x for x in [self.dfa.walk(s) for s in
                           self.sample.negative] if x in self.reds - self.dfa.fas)

    def __call__(self):
        while self.blues:
            promote = True
            blue = self.choose()
            self.blues.remove(blue)
            for red in self.reds:
                proxy = self.merge(red, blue)
                dfa = DFA(proxy.fas, proxy.ttable, proxy.frs, proxy.unlabelled)
                if compatible(dfa, self.sample):
                    self.dfa = dfa 
                    for s in self.dfa.alphabet:
                        next = self.dfa.ttable.get((red, s))
                        if next is not None and next not in self.reds:
                            self.blues.add(next)
                    promote = False
                    break
            if promote:
                self.promote(blue)
        self.update_frs()
        return self.dfa


if __name__ == '__main__':
    from pprint import pformat

    sample = [
        ('aaaabaaaa', 1),
        ('aabaaaaa', 1),
        ('ab', 1),
        ('aaaaaaaaaab', 1),
        ('ababb', 1),
        ('bbb', 1),
        ('aaaabbb', 1),
        ('baaaa', 1),
        ('a', 0),
        ('aaabaaab', 0),
        ('abab', 0),
        ('bb', 0),
        ('aaaaaabb', 0),
        ('bbaaaaa', 0),
    ]

    rpni = RPNI(sample)
    dfa = rpni()

    print "digraph finite_state_machine {"
    print "\trankdir=LR;"
    print "\tnode [shape = doublecircle];"
    for fa in rpni.dfa.fas:
        print "\t%s;" % (fa,)
    print "\tnode [shape = circle];"
    for k, v in dfa.ttable.iteritems():
        print '\t%s -> %s [label = "%s"];' % (k[0], v, k[1])
    print "}"
