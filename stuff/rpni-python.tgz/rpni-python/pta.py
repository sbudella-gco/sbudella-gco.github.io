from dfa import DFA, StateUndefined 


class Sample(object):
    def __init__(self, sequence):
        self.positive = frozenset(s for s, flag in self.pack(sequence) if flag)
        self.negative = frozenset(s for s, flag in self.pack(sequence) if not flag)
        self.both = self.positive | self.negative

    @staticmethod
    def pack(sequence):
        try:
            s, flag = sequence[0]
        except (ValueError, TypeError):
            return ((s, 1) for s in sequence)
        else:
            return sequence

    def __iter__(self):
        return self.both.__iter__()


def shrink(xs):
    return [x[1:] for x in xs if len(x) > 1] 

def unique_prefixes(xs):
    return reduce(lambda x, y: x + [y[0]] if y[0] not in x else x, xs, [])

def fork_by_pref(xs):
    for pref in unique_prefixes(xs):
        yield (pref, [x for x in xs if x[0] == pref])


def naming_fn(unlabelled=str()):
    def g():
        n = unlabelled if isinstance(unlabelled, int) else 0 
        while True:
            n += 1
            yield n 

    def strings(root, symbol):
        return root + symbol

    single = g()
    def integers(root, symbol):
       return single.next()

    if isinstance(unlabelled, str):
        return strings
    elif isinstance(unlabelled, int):
        return integers
    else:
        raise TypeError('Only strings or integers allowed for naming type.')


class PTA(DFA):
    def __init__(self, sample, unlabelled=str()):
        sample = sample if isinstance(sample, Sample) else Sample(sample)
        super(PTA, self).__init__(None,
                                  self.__build_ttable(sample, unlabelled),
                                  None,
                                  unlabelled)
        self.fas = set(x for x in [self.walk(s) for s in sample.positive]
                                                    if x != StateUndefined)
        self.frs = set(x for x in [self.walk(s) for s in sample.negative]
                                                    if x != StateUndefined)

    @staticmethod
    def __build_ttable(sample, unlabelled=str()):
        state_name = naming_fn(unlabelled)
        def traverse(root, sample):
            for cur_symbol, next_states in fork_by_pref(sample):
                target_state = state_name(root, cur_symbol)  
                yield ((root, cur_symbol), target_state)
                for rest in traverse(target_state, shrink(next_states)):
                    yield rest

        return dict(traverse(unlabelled, sample))


if __name__ == "__main__":
    from pprint import pprint

    sample = Sample([
        ('aa', 1),
        ('aba', 1),
        ('bba', 1),
        ('ab', 0),
        ('abab', 0)
    ])
    
    pta = PTA(sample, int())
    pprint(pta.ttable)
    pprint(pta.fas)
    pprint(pta.frs)
    pprint(pta.alphabet)
