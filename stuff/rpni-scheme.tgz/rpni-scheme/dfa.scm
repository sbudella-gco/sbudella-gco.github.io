(module dfa 
 (table->trans-func DFA)

 (import chicken scheme)
 (use srfi-1)          ; fold
 (use srfi-69)         ; hash-tables
 (use data-structures) ; flip combinator
 (use backbone)


 (define (table->trans-func table)
  (lambda (exit)
   (lambda (state symbol)
    (let ((r (look-table (make-key state symbol) table)))
     (if (eq? r #f) (exit #f)
      (extract-state r))))))


 (define (DFA S d q0 Fa Fr)
   (lambda msg
    (define (accept sequence)
     (in (walk sequence) Fa))

    (define (walk sequence)
     (call-with-current-continuation
      (lambda (k)
       (fold (flip (d k)) q0 sequence))))

    (let ((msg (optional msg 'walk)))
     (cond ((eq? msg 'walk) walk)
           ((eq? msg 'accept) accept)
           (else (error "Undefined dfa action: " msg))))))

) ; end module
