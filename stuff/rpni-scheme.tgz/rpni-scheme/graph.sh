#! /bin/sh

set -eu

if [ $# -lt 1 ]; then
	print "usage: $0 <sample>"
	exit 1
fi

NAME=${1##*/}
NAME=${NAME%%.*}
RENDER=$(which dot 2>/dev/null && echo "tee "$NAME".gv | dot -T png -o "$NAME".png" || echo "tee > "$NAME".gv")
[ -f "$1" ] && ./draw.scm <"$1" 4>"$NAME".dump | eval "$RENDER" || \
{ print "$1: no such file or directory." >&2 ; exit 1; }

print "Machine dump: "$NAME".dump"
print "Graph: ${RENDER##* }"
if [ which dot 2>/dev/null ]; then
	print "Drawing: "$NAME".png"
fi
