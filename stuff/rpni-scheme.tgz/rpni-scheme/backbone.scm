(module backbone
 (init-table last-state look-table extract-key extract-state
  make-elem make-key in key-state-less? less-eq? seq->string
  alpha-length-less? alpha-less? purge)

 (import chicken scheme)
 (use srfi-1)
 (use alist)


 (define (key-state-less? x y)
  (<= (car (extract-key x)) (car (extract-key y))))


 (define (less-eq? x y)
  (cond ((and (number? x) (number? y)) (<= x y))
        ((and (symbol? x) (symbol? y)) (string<=? (symbol->string x) (symbol->string y)))
        ((and (string? x) (string? y)) (string<=? x y))
        ((and (char? x) (char? y)) (char<=? x y))
        (else (error 'less-eq? "Invalid types for comparison" x y))))


 (define (seq->string xs)
  (define (convert x)
   (cond ((number? x) (string-ref (number->string x) 0))
         ((symbol? x) (string-ref (symbol->string x) 0))
         ((string? x) (string-ref x 0))
         ((char? x) x)
         (else (error 'seq->string "Invalid type for conversion" x))))
  (list->string (map convert xs)))


 (define (alpha-length-less? xs ys)
  (let ((xlen (length xs)) (ylen (length ys)))
   (or (< xlen ylen)
    (and (= xlen ylen) (string<=? (seq->string xs) (seq->string ys))))))

 (define (alpha-less? xs ys)
  (string<=? (seq->string xs) (seq->string ys)))


 (define (purge xss)
  (define (average xs) (/ (apply + xs) (length xs)))

  (define (deviation xs)
   (let ((mean (average xs)) (len (length xs)))
     (sqrt (/ (apply + (map (lambda (x) (let ((elm (- x mean))) (* x x))) xs)) len))))
   
  (let* ((lens (map length xss)) (dev (deviation lens)) (mean (average lens)))
   (filter 
    (lambda (seq)
     (< (abs (- (length seq) mean)) (* 1.5 dev)))
    xss)))

) ; end module


