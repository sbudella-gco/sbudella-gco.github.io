(module utilities
 (read-samples)

 (import chicken scheme ports)
 (use backbone)


 (define (read-samples . port)
  (define (decode flag)
   (cond ((number? flag) (if (eqv? flag 0) #f #t))
         ((boolean? flag) flag)
         (else (error "Invalid flag format for sample" flag))))

  (let ((port (optional port (current-input-port))))
   (let loop ((input (read port)) (pos-sample '()) (neg-sample '()))
    (if (eq? input '()) (values pos-sample neg-sample)
     (let ((sample (caar input)) (flag (cdar input)))
      (if (decode flag) (loop (cdr input) (cons sample pos-sample) neg-sample)
       (loop (cdr input) pos-sample (cons sample neg-sample))))))))

) ; end module
