/*====================
==	curuncula_24.c (for 2.4 kernels);
==	author: sbudella (Giuseppe Cocomazzi);
==	contact: sbudella@gmail.com;
==	date: september 2008;
==	usage: make && insmod curuncula_24.o
==	description: modern rootkits make use of the intel debugging
==		support facilities to achieve stealthness so that
==		every time a sensible memory location is hit by the
==		kernel, a debug exception is generated; this exception
==		is dealt by a custom malicious handler which can
==		modify the system behaviour in the manner common
==		to most rootkits (such as syscall hijacking, etc).
==		This little module helps detecting this genre of
==		malware using a simple paradigm: when a debug
==		exception arrives, the processor cleans the lbr
==		(last branch record) bit in the DEBUGCTLMSR to
==		help with the dubugging mechanism; so we set
==		the lbr and assume that a evil handler is managing
==		our exceptions; back from the handler we check again
==		the lbr bit and if it's cleared we infer that a #db
==		occurred while accessing %dr registers. Nevertheless,
==		the evil handler could reset the lbr just before
==		returning the execution, but we catch this behaviour too
==		using the lbr bit cleared and checking its clearness
==		after the exception: so if the lbr bit is dirty, we
==		detect an anomaly, since the dafault debug exception
==		handler does not care about lbr resetting.
==	license: gnu general public license, version 2;
====================*/

#define __KERNEL__
#define MODULE
#define LINUX
#ifdef CONFIG_MODVERSIONS
#define MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/string.h>

#define DEBUGCTLMSR                     0x1d9
#define LASTBRANCHFROMIP                0x1db
#define LASTBRANCHTOIP                  0x1dc
#define LASTEXCEPTIONFROMIP             0x1dd
#define LASTEXCEPTIONTOIP               0x1de

#define rdmsr(msr, val1, val2) \
	__asm__ __volatile__("rdmsr" \
		: "=a" (val1), "=d" (val2) \
		: "c" (msr))

#define wrmsr(msr, val1, val2) \
	__asm__ __volatile__("wrmsr" \
		: \
		: "c" (msr), "a" (val1), "d" (val2))

struct {
	unsigned lbr:		1;
	unsigned btf:		1;
	unsigned pbi:		4;
	unsigned tr:		1;
	unsigned reserved:	25;
} __attribute__ ((packed)) dbgmsr = { 1 };

struct debug_reg7 {
	unsigned l0:		1;
	unsigned g0:		1;
	unsigned l1:		1;
	unsigned g1:		1;
	unsigned l2:		1;
	unsigned g2:		1;
	unsigned l3:		1;
	unsigned g3:		1;
	unsigned others:	24;
} __attribute__ ((packed));

void get_dr(unsigned int x, unsigned long *y);
void dummy_branch(void);
void print_lg(unsigned int i, unsigned long addr);

unsigned long h = 0;

int init_module(void)
{
	unsigned long tmp;
	unsigned int i, flag = 0;
       
	printk("<1>*** curuncula by sbudella (Giuseppe Cocomazzi) "
							"september 2008 ***\n");
	printk("<1>    *** detect rootkits with debugging support "
							"facilities ***\n");

	/*
	 * activate the last branch recording mechanism and make the
	 * addresses in the branch msr's change, just to confuse any
	 * rootkit which wants to use them to infer detection.
	 */
	wrmsr(DEBUGCTLMSR, dbgmsr, h);
	dummy_branch();

	/* reset initial state */
	memset(&dbgmsr, 0, 32);
	wrmsr(DEBUGCTLMSR, dbgmsr, h); 

	/*
	 * if the GD flag is set in %dr7 and debug register %dri
	 * is active, this will generate a #db exception for every
	 * access on each debug register.
	 */
	for (i = 0; i < 4; i++) {
		get_dr(i, &tmp);
		rdmsr(DEBUGCTLMSR, dbgmsr, h);
		switch (dbgmsr.lbr) {
		case 0:
			break;
		case 1:
			/* the evil handler has reset the lbr bit */ 
			printk("<1>lbr bit reset; default debug exception "
					"handler does not behave this way;\n");
			printk("<1>*** WARNING! anomaly detected! ***\n");
			flag++;
			break; 
		}
	}

	if (flag)
		goto BAD_END;

	/* do the same with lbr bit set */
	for (i = 0; i < 4; i++) {
		memset(&dbgmsr, 0, 32);
		dbgmsr.lbr = 1;
		h = 0;
		wrmsr(DEBUGCTLMSR, dbgmsr, h);

		get_dr(i, &tmp);
		rdmsr(DEBUGCTLMSR, dbgmsr, h);
		switch (dbgmsr.lbr) {
		case 0:
			/*
			 * the evil handler has not reset the lbr bit;
			 * anyway lbr cleared implies that a #db exception
			 * has occurred.
			 */
			printk("<1>lbr bit cleared;\n");
			printk("<1>#db exception while trying to access "
								"dr%d;\n", i);
			printk("<1>*** WARNING! anomaly detected! ***\n");
			flag++;
			break;
		case 1:
			/*
			 * at this stage of execution we have already checked
			 * whether the handler had reset the lbr bit, and
			 * this is not the case; lbr set here implies either
			 * that no rootkit is installed, or that GD flag is not
			 * set, hence we can easily read debug registers to
			 * further investigate.
			 */
			printk("<1>no #db exception while trying to access "
								"dr%d;\n", i);
			printk("<1>-> checking dr%d value: ", i);
			if (tmp) {
				struct debug_reg7 dr7 = { 0 };
				get_dr(7, (unsigned long *) &dr7);

				switch (i) {
				case 0:
					if (dr7.l0 || dr7.g0) {
						print_lg(i, tmp);
						flag++;
					}
					printk("dr%d = 0x%lx but not active;\n",
									i, tmp);
					break;
				case 1:
					if (dr7.l1 || dr7.g1) {
						print_lg(i, tmp);
						flag++;
					}
					printk("dr%d = 0x%lx but not active;\n",
									i, tmp);
					break; 
				case 2:
					if (dr7.l2 || dr7.g2) {
						print_lg(i, tmp);
						flag++;
					}
					printk("dr%d = 0x%lx but not active;\n",
									i, tmp);
					break;
				case 3:
					if (dr7.l3 || dr7.g3) {
						print_lg(i, tmp);
						flag++; 
					}
					printk("dr%d = 0x%lx but not active;\n",
									i, tmp);
					break;
				}
			} else
				printk("dr%d clean;\n", i);
			break;
		}
	}	

	if (flag)
		goto BAD_END;

	printk("<1>\nyour system seems to be clean;\n");
	printk("<1>no rootkit with debugging support facilities detected.\n");
	return 0;

BAD_END:
	printk("<1>\nthere are good chances that a rootkit with debugging\n"
				"<1>support facilities has been installed.\n");
	return 0;

}

void cleanup_module(void)
{
	memset(&dbgmsr, 0, 32);
	h = 0;
	wrmsr(DEBUGCTLMSR, dbgmsr, h);

}

/*
 * this is going to be used in a loop, as get_dr(i, tmp)
 * so forget making it cool with the # preprocessor operator.
 */
void get_dr(unsigned int x, unsigned long *y)
{
	switch (x) {
	case 0:
		__asm__ __volatile__("movl	%%dr0, %0" : "=r" (*y));
		break;
	case 1:
		__asm__ __volatile__("movl	%%dr1, %0" : "=r" (*y));
		break;
	case 2:
		__asm__ __volatile__("movl	%%dr2, %0" : "=r" (*y));
		break;
	case 3:
		__asm__ __volatile__("movl	%%dr3, %0" : "=r" (*y));
		break;
	case 7:
		__asm__ __volatile__("movl	%%dr7, %0" : "=r" (*y));
		break;
	}

}

void dummy_branch(void)
{
	printk("<1>\ndummy_branch@0x%lx\n", (unsigned long) dummy_branch);
}

void print_lg(unsigned int i, unsigned long addr)
{
	printk("local/global breakpoint enable on dr%d; "
						"dr%d = 0x%lx;\n", i, i, addr);
	printk("<1>*** WARNING! anomaly detected! ***\n");
	printk("<1>** please check which symbol matches to 0x%lx;\n", addr);
}

MODULE_LICENSE("GPL");
