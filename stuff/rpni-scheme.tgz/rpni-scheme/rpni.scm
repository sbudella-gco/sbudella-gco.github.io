(module rpni (rpni section-from rpni-merge rpni-compatible?)

 (import chicken scheme)
 (use srfi-1)
 (use data-structures)
 (use backbone)
 (use dfa)
 (use pta)


 (define (section-from table)
  (lambda (state)
   (let ((elements (filter (lambda (elem) (eqv? (car (extract-key elem)) state)) table)))
    (let* ((successors (map (lambda (elem) (extract-state elem)) elements))
           (unfolded (map (section-from table) successors)))
     (apply append elements unfolded)))))


 (define (rpni-fold qr qb red-table blue-table S Fas)
  (let ((red-table red-table) (blue-table blue-table) (Fas Fas))
   (let do-fold ((qr qr) (qb qb))
    (if (in qb Fas) (set! Fas (append (delete qb Fas) (list qr))))
    (for-each
     (lambda (symbol)
      (let ((blue-next (look-table (make-key qb symbol) blue-table))
            (red-next (look-table (make-key qr symbol) red-table)))
       (if blue-next
        (if red-next
         (do-fold (extract-state red-next) (extract-state blue-next))
         (let* ((junction-state (extract-state blue-next))
                (junction-elem (make-elem (make-key qr symbol) junction-state))
                (section-branch ((section-from blue-table) junction-state))
                (new-red-table (append red-table (cons junction-elem section-branch))))
          (set! red-table new-red-table))))))
     S))
   (values red-table (delete-duplicates Fas))))


 (define (rpni-merge qr qb table S Fas)
  (let* ((blue-table ((section-from table) qb))
         (red-table 
   (let loop ((table (remove (lambda (q) (in q blue-table)) table)) (result '()))
    (if (eq? table '()) result
     (let* ((elem (car table)) (state (extract-state elem)) (key (extract-key elem)))
      (if (eqv? state qb) (loop (cdr table) (cons (make-elem key qr) result))
       (loop (cdr table) (cons elem result))))))))
   (rpni-fold qr qb red-table blue-table S Fas)))


 (define (rpni-compatible? table neg-sample S Fas)
  (call-with-current-continuation
   (lambda (exit-cont)
    (let ((dfa-accept? ((DFA S (table->trans-func (init-table table)) 0 Fas '()) 'accept)))
     (for-each
      (lambda (string)
       (if (dfa-accept? string) (exit-cont #f)))
       neg-sample))
    #t)))


 (define (find-blues q table S . extract-proc)
  (let ((extract-proc (optional extract-proc (lambda (x) x))))
   (remove (lambda (x) (eq? x #f))
    (map
     (lambda (symbol)
      (let ((elem (look-table (make-key q symbol) table)))
       (if elem (extract-proc elem) #f)))
     S))))


 (define (update-blues q table S blues . remove-pred?)
  (let ((remove-pred? (optional remove-pred? #f)))
   (append blues
    (remove (lambda (x) (in x blues))
     (map (lambda (x) (extract-state x))
      (if remove-pred? (remove remove-pred? (find-blues q table S))
       (find-blues q table S)))))))


 (define (rpni pos-sample neg-sample)
  (define (choose blues)
   (car (sort blues <)))

  (call-with-current-continuation
   (lambda (exit-cont)
    (let-values (((table Fas) (build-table&fas (purge (sort pos-sample alpha-less?))))
                 ((S) (sort (alphabet pos-sample) less-eq?))
                 ((reds) '(0)))

     (define (loop reds blues table Fas)
      (if (eq? blues '()) (call-with-values (lambda () (values table Fas)) exit-cont)
       (let ((qb (choose blues)))
        (call-with-current-continuation
         (lambda (break)
          (for-each
           (lambda (qr)
            (let-values (((proxy-table proxy-Fas) (rpni-merge qr qb table S Fas)))
             (if (rpni-compatible? proxy-table neg-sample S proxy-Fas)
              (break
               (loop reds
                     (update-blues qr proxy-table S (delete qb blues) (lambda (elem) (in (extract-state elem) reds)))
                     proxy-table proxy-Fas)))))
           reds)))
         (loop (append reds (list qb))
               (update-blues qb table S (delete qb blues))
               table Fas))))

     (loop reds
           (find-blues (car reds) table S (lambda (x) (extract-state x)))
           table Fas)))))
) ; end module 
