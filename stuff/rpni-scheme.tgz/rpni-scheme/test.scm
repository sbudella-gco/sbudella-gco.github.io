#! /usr/local/bin/csi -script

(use utilities)
(use backbone)
(use dfa)
(use pta)
(use rpni)


(let* ((data (read (open-input-file (car (command-line-arguments)))))
       (S (car data))
       (table (cadr data))
       (Fas (caddr data))
       (accept ((DFA S (table->trans-func (init-table table)) 0 Fas '()) 'accept)))
  (let ((test-strings (read)))
   (for-each
    (lambda (string)
     (print string " ---> " (accept string)))
    test-strings)))
